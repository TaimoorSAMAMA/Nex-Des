const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const Review = require("./review.js");

const listingSchema = new Schema({
  title: {
    type: String,
    required: true,
  },
  description: String,
  image: {
    type: String,
    default:
      "https://w0.peakpx.com/wallpaper/230/664/HD-wallpaper-peaceful-place-architecture-pretty-colorful-house-summer-time-grass-sunny-yellow-beautiful-clouds-leaves-splendor-green-beauty-blue-hills-lovely-view-houses-colors-sky-trees-peaceful.jpg",
    set: (v) =>
      v === ""
        ? "https://w0.peakpx.com/wallpaper/230/664/HD-wallpaper-peaceful-place-architecture-pretty-colorful-house-summer-time-grass-sunny-yellow-beautiful-clouds-leaves-splendor-green-beauty-blue-hills-lovely-view-houses-colors-sky-trees-peaceful.jpg"
        : v,
  },
  price: Number,
  location: String,
  country: String,
  reviews: [
    {
      type: Schema.Types.ObjectId,
      ref: "review",
    },
  ],
});

listingSchema.post("findOneAndDelete", async (listing) => {
  if (listing) {
    await Review.deleteMany({ _id: { $in: listing.reviews } });
  }
});

const Listing = mongoose.model("Listing", listingSchema);
module.exports = Listing;
